<?php
/**
 * Hello World! Module Entry Point
 * 
 * @package    Joomla.Tutorials
 * @subpackage Modules
 * @license    GNU/GPL, see LICENSE.php
 * @link       http://docs.joomla.org/J3.x:Creating_a_simple_module/Developing_a_Basic_Module
 * mod_helloworld is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
 
// No direct access
defined('_JEXEC') or die;
// Include the syndicate functions only once
require_once dirname(__FILE__) . '/helper.php';
 
$hello = modHelloWorldHelper::getHello($params);
require JModuleHelper::getLayoutPath('mod_helloworld');

$option = array(); //prevent problems
 
$option['driver']   = 'mysql';            // Database driver name
$option['host']     = 'localhost';    // Database host name
$option['user']     = 'user01';       // User for database authentication
$option['password'] = 'user01';   // Password for database authentication
$option['database'] = 'Schokoladenfabrik';      // Database name
$option['prefix']   = '';             // Database prefix (may be empty)
 
$db = JDatabaseDriver::getInstance( $option );
//parent::setDbo($db);
		
// Get a database object
//$db = JFactory::getDbo();

$query = $db->getQuery(true);
$query->select('bezeichnung');
$query->from('Produkt');

// sets up a database query for later execution
$db->setQuery($query);

// fetch result as an object list
$result = $db->loadObjectList();

echo '<table border="1">';
echo '<tr>';
echo '<td>';
echo '<b>Bezeichnung';
foreach ( $result as $row ) {
	echo '<tr>';
	echo '<td>';
		echo $row->bezeichnung;
	echo '</td>';
	echo '</tr>';
}
echo '</td>';
echo '</td>';
echo '</table>';


?>